# mqaid
An MQA identifier for "lossless" flac files. See https://en.wikipedia.org/wiki/Master_Quality_Authenticated

Requires Python 3.5+ and module 'bitstring'
